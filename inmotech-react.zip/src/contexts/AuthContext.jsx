import { createContext, useState } from "react";
import { api } from "../api";
export const AuthContext = createContext();
export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    async function login(email, password) {
        const res = await api.post("/auth/login", { email, password });
        const token = res.headers.authorization.split(" ")[1];
        localStorage.setItem("token", token);
        setUser(email);
    }
    function logout() {
        localStorage.removeItem("token");
        setUser(null);
    }
    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
}
