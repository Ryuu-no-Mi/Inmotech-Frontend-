import { useEffect, useState } from "react";
import { api } from "../api";
import SearchBar from "../components/SearchBar";
import PropertyDetail from "../components/PropertyDetail";

export default function Home() {
    const [propsData, setPropsData] = useState([]);
    const [query, setQuery] = useState("");
    useEffect(() => {
        api.get("/property").then((r) => setPropsData(r.data));
    }, []);
    const filtered = propsData.filter((p) =>
        p.titulo.toLowerCase().includes(query.toLowerCase())
    );
    return (
        <div>
            <SearchBar onSearch={setQuery} />
            {filtered.map((p) => (
                <PropertyDetail key={p.id} prop={p} />
            ))}
        </div>
    );
}
