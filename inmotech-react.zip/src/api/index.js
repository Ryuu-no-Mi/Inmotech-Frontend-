import axios from "axios";
export const api = axios.create({
    baseURL: "http://localhost:8080/api",
});
// Interceptor para añadir JWT desde localStorage
api.interceptors.request.use((jwt) => {
    const token = localStorage.getItem("token");
    if (token) jwt.headers.Authorization = `Bearer ${token}`;
    return jwt;
});
