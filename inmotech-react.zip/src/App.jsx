import './App.css'
import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import SearchBar from './components/SearchBar'
import PropertyList from './components/PropertyList'
import PropertyDetail from "./components/PropertyDetail"
import Footer from './components/Footer'
import Favoritos from './components/Favoritos'
import RegisterUser from './components/RegisterUser'
import UserLogin from './components/UserLogin'
import { BrowserRouter } from 'react-router-dom'
import Home from './pages/Home'
import Property from './pages/Property'
import { AuthProvider } from './context/AuthContext'
import { api } from './api'
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import { Heart, HeartOff } from 'lucide-react'
import { useContext } from 'react'
import { AuthContext } from './context/AuthContext' 

function App() {

  return (
      <>
          <AuthProvider>
              <BrowserRouter>
                  <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/property/:id" element={<Property />} />
                  </Routes>
              </BrowserRouter>
          </AuthProvider>
      </>
  );
}

export default App
