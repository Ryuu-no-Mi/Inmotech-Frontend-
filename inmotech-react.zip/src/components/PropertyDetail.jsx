import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

export default function PropertyDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [property, setProperty] = useState(null);
    const [user, setUser] = useState(null);

    useEffect(() => {
        fetch(`http://localhost:8080/api/property/${id}`)
            
            .then((res) => res.json())
            .then((data) => setProperty(data))
            .catch((err) => console.error("Error al cargar propiedad:", err));
        
        
    }, [id]);

    useEffect(() => {
        fetch(`http://localhost:8080/api/user`)
            .then((res) => res.json())
            .then((data) => setUser(data))
            .catch((err) => console.error("Error al cargar el usuario:", err));
    });

    if (!property) return <div className="p-4">Cargando...</div>;

    const imagenPortada = property.imagenPortada?.url
        ? property.imagenPortada
        : property.imagenes?.find((img) => img.esPortada) ||
        property.imagenes?.[0];
    

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <img
                src={imagenPortada?.url}
                alt={property.titulo}
                className="w-full h-full object-cover rounded"
            />
            <h1 className="text-3xl font-bold mt-4">{property.titulo}</h1>
            <p className="text-lg text-gray-700 mt-2">{property.descripcion}</p>

            <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                    <p>
                        <strong>Dirección: </strong> {property.direccion}
                    </p>
                    <p>
                        <strong>Provincia: </strong>
                        {property.provincia}
                    </p>
                    <p>
                        <strong>Ciudad: </strong> {property.ciudad}
                    </p>
                    <p>
                        <strong>Código postal: </strong> {property.codigoPostal}
                    </p>
                </div>
                <div>
                    <p>
                        <strong>Superficie:</strong> {property.superficie} m²
                    </p>
                    <p>
                        <strong>Precio:</strong>{" "}
                        <span className="text-indigo-600 font-bold">
                            {property.precio.toLocaleString()} €
                        </span>
                    </p>
                    <p>
                        <strong>Publicado el:</strong>{" "}
                        {property.fechaPublicacion?.split("T")[0]}
                    </p>
                </div>
            </div>

            {/* Galería de imágenes */}
            <div className="mt-6">
                <h2 className="text-xl font-semibold mb-2">Galería</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {property.imagenes?.map((img) => (
                        <img
                            key={img.id}
                            src={img.url}
                            alt={`Imagen ${img.id}`}
                            className="w-full h-40 object-cover rounded"
                            onError={(e) => {
                                e.target.onerror = null;
                                e.target.src =
                                    "https://media.istockphoto.com/id/1472933890/es/vector/no-hay-s%C3%ADmbolo-vectorial-de-imagen-falta-el-icono-disponible-no-hay-galer%C3%ADa-para-este.jpg?s=612x612&w=0&k=20&c=fTxCETonJ20MRRE6DFU9pbGws6e7sa1uySP49wU372I=";
                            }}
                        />
                    ))}
                </div>
            </div>

            {/* Propietario */}
            <div className="mt-6 border-t pt-4">
                <h2 className="text-xl font-semibold mb-2">Publicado por</h2>
                <div className="bg-gray-100 p-4 rounded shadow-sm">
                    <img
                        src={
                            property.usuario?.imagen?.url ||
                            "https://img.freepik.com/vector-premium/icono-circulo-usuario-anonimo-ilustracion-vector-estilo-plano-sombra_520826-1931.jpg"
                        }
                        alt={property.usuario?.nombre}
                        className="w-24 h-24 rounded-full object-cover mb-2"
                        onError={(e) => {
                            e.target.onerror = null;
                            e.target.src =
                                "https://cdn-icons-png.flaticon.com/512/847/847969.png";
                        }}
                    />
                    <p>
                        <strong>Nombre:</strong> {property.usuario?.nombre}
                    </p>
                    <p>
                        <strong>Email:</strong> {property.usuario?.email}
                    </p>
                    <p>
                        <strong>Teléfono:</strong>{" "}
                        {property.usuario?.telefono || "No disponible"}
                    </p>

                    {property.usuario?.agencia && (
                        <div className="mt-4">
                            <p className="text-sm text-gray-600">
                                Este usuario pertenece a una agencia
                                inmobiliaria.
                            </p>
                            <button
                                onClick={() =>
                                    navigate(
                                        `/agencia/${property.usuario.agencia.id}`
                                    )
                                }
                                className="mt-2 px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                            >
                                Ver detalles de la agencia
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {/* Formulario de consulta */}
            <div className="mt-6 border-t pt-4">
                <h2 className="text-xl font-semibold mb-2">
                    ¿Interesado? Envía una consulta
                </h2>
                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        const mensaje = e.target.mensaje.value;
                        if (!mensaje.trim()) return;

                        fetch("http://localhost:8080/api/inquiry", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                            },
                            body: JSON.stringify({
                                mensaje,
                                usuario: {id: 5}, // ← reemplaza con el ID del usuario actual autenticado si lo tienes
                                propiedad: { id: property.id }
                            }),
                        })
                            .then((res) => {
                                if (res.ok) {
                                    alert("Mensaje enviado correctamente.");
                                    e.target.reset();
                                } else {
                                    throw new Error("Error al enviar consulta");
                                }
                            })
                            .catch((err) => alert("Error: " + err.message));
                    }}
                    className="flex flex-col gap-3"
                >
                    <textarea
                        name="mensaje"
                        rows="4"
                        placeholder="Escribe tu mensaje para el propietario..."
                        className="border border-gray-300 rounded p-2"
                        required
                    ></textarea>
                    <button
                        type="submit"
                        className="self-start px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-500 transition"
                    >
                        Enviar consulta
                    </button>
                </form>
            </div>

            {/* Botón volver */}
            <div className="mt-8">
                <button
                    onClick={() => navigate(-1)}
                    className="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition"
                >
                    ← Volver
                </button>
            </div>
        </div>
    );
}
