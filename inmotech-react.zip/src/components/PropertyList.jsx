import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import SearchBar from "./SearchBar";
import { Heart, HeartOff } from "lucide-react"; 


export default function PropertyList() {
    const [properties, setProperties] = useState([]);
    const navigate = useNavigate();
    const [filtered, setFiltered] = useState([]);
    const [favorites, setFavorites] = useState([]);
    const userId = 2; // ← sustituye por el ID real del usuario autenticado

    const handleLike = async (propertyId) => {
        const isFav = favorites.includes(propertyId);

        try {
            const url = `http://localhost:8080/api/favourite/${userId}/${propertyId}`;
            await fetch(url, { method: isFav ? "DELETE" : "POST" });

            setFavorites((prev) =>
                isFav
                    ? prev.filter((id) => id !== propertyId)
                    : [...prev, propertyId]
            );
        } catch (err) {
            console.error("Error al actualizar favorito:", err);
        }
    };

    useEffect(() => {
        // cargar todas lass propiedades
        fetch("http://localhost:8080/api/property")
            .then((res) => res.json())
            .then((data) => {
                setProperties(data);
                setFiltered(data);
            })
            .catch((err) =>
                console.error("Error al obtener propiedades:", err)
            );

        // cargar favoritos del usuario logueado
        fetch(`http://localhost:8080/api/favourite/${userId}`)
            .then((res) => res.json())
            .then((data) => {
                console.log("Favoritos del backend:", data); // AÑADE ESTO
                const favoritosIds = data.map((fav) => fav.propiedad.id);
                setFavorites(favoritosIds);
            })
            .catch((err) => console.error("Error al obtener favoritos:", err));
    }, []);

    const handleSearch = ({ ubicacion, tipo, precio }) => {
        let results = properties;

        if (ubicacion) {
            results = results.filter((p) =>
                `${p.ciudad} ${p.provincia} ${p.direccion}`
                    .toLowerCase()
                    .includes(ubicacion.toLowerCase())
            );
        }

        if (tipo) {
            results = results.filter((p) =>
                p.titulo.toLowerCase().includes(tipo.toLowerCase())
            );
        }

        if (precio) {
            if (precio === "1-100000")
                results = results.filter((p) => p.precio <= 100000);
            if (precio === "100000-299999")
                results = results.filter(
                    (p) => p.precio > 100000 && p.precio <= 299999
                );
            if (precio === "300000-499999")
                results = results.filter(
                    (p) => p.precio > 300000 && p.precio <= 499999
                );
            if (precio === "500000+")
                results = results.filter((p) => p.precio > 500000);
        }

        setFiltered(results);
    };

    return (
        <div className="p-4">
            <SearchBar onSearch={handleSearch} />

            <div className="property-list grid gap-4 mt-4 md:grid-cols-2 lg:grid-cols-3">
                {filtered.map((property) => (
                    <div
                        key={property.id}
                        onClick={() => navigate(`/property/${property.id}`)}
                        className="relative cursor-pointer bg-white rounded shadow overflow-hidden hover:shadow-lg transition"
                    >
                        {/* Botón de Me Gusta */}
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                handleLike(property.id);
                            }}
                            className="absolute top-2 right-2 z-10 bg-white p-1 rounded-full shadow hover:scale-110 transition"
                        >
                            {favorites.includes(property.id) ? (
                                <Heart className="text-red-500 fill-red-500" />
                            ) : (
                                <HeartOff className="text-gray-400" />
                            )}
                        </button>

                        <img
                            src={property.imagenPortada?.url}
                            onError={(e) => {
                                e.target.onerror = null;
                                e.target.src =
                                    "https://media.istockphoto.com/id/1472933890/es/vector/no-hay-s%C3%ADmbolo-vectorial-de-imagen-falta-el-icono-disponible-no-hay-galer%C3%ADa-para-este.jpg?s=612x612";
                            }}
                            alt={property.titulo}
                            className="w-full h-64 object-cover"
                        />

                        <div className="p-4">
                            <h3 className="text-xl font-semibold">
                                {property.titulo}
                            </h3>
                            <p className="text-lg text-gray-800">
                                {property.direccion}
                            </p>
                            <p className="text-sm text-gray-400">
                                <span className="font-medium">
                                    {property.provincia}
                                </span>
                                , {property.ciudad}
                            </p>
                            <p className="text-indigo-600 font-bold text-2xl mt-2">
                                {property.precio.toLocaleString()} €
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
