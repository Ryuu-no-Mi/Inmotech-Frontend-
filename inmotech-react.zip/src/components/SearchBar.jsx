import { useState } from 'react';

export default function SearchBar({ onSearch}) {
    const [ubicacion, setUbicacion] = useState("");
    const [tipo, setTipo] = useState("");
    const [precio, setPrecio] = useState("");

    const handleSubmit = () => {
        onSearch({ ubicacion, tipo, precio });
    };

    return (
        <div className="search-bar flex items-center justify-between p-4 bg-gray-100 border border-gray-300 rounded shadow-md">
            <input
                type="text"
                placeholder="Buscar por ubicación"
                value={ubicacion}
                onChange={(e) => setUbicacion(e.target.value)}
                className="flex-1 mr-2 p-2 border border-gray-300 rounded"
            />
            <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value)}
                className="mr-2 p-2 border border-gray-300 rounded"
            >
                <option value="">Tipo de propiedad</option>
                <option value="Piso">Piso</option>
                <option value="Casa">Casa</option>
                <option value="Ático">Ático</option>
                <option value="Chalet">Chalet</option>
            </select>
            <select
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
                className="mr-2 p-2 border border-gray-300 rounded"
            >
                <option value="">Todos los precios</option>
                <option value="1-100000">1 - 100.000€</option>
                <option value="100000-299999">100.000€ - 299.999€</option>
                <option value="300000-499999">300.000€ - 499.999€</option>
                <option value="500000+">Más de 5000.000€</option>
            </select>
            <button
                onClick={handleSubmit}
                className="bg-indigo-500 text-white px-4 py-2 rounded"
            >
                Buscar
            </button>
        </div>
    );
}
