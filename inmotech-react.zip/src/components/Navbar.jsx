
    import { Link } from "react-router-dom";
export default function Navbar() {
    return (

        <nav className="bg-indigo-600 text-white px-4 py-3 shadow">
            <div className="container mx-auto flex justify-between items-center">
                <div className="text-lg font-semibold">
                    <Link to="/" className="text-4xl hover:text-gray-300">InmoTech</Link>
                </div>
                <div className="space-x-4">
                    <Link to="/" className="hover:text-gray-300">Inicio</Link>
                    <Link to="/userLogin" className="hover:text-gray-300">Iniciar Sesión</Link>
                    <Link to="/registerUser" className="hover:text-gray-300">Registrarse</Link>
                </div>
            </div>
        </nav>
    );
}

